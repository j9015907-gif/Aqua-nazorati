================================================
  AQILLI SUV NAZORATI — SERVER DEPLOYMENT
================================================

Bu paket 2 qismdan iborat:

  1. frontend/   — tayyor HTML/CSS/JS fayllar (Nginx yoki Apache bilan serve qilinadi)
  2. backend/    — Node.js API server (index.mjs)

================================================
  TALABLAR
================================================

  - Node.js v18 yoki undan yuqori
  - PostgreSQL 14+
  - Nginx yoki Apache (frontend uchun)

================================================
  1. POSTGRESQL MA'LUMOTLAR BAZASINI SOZLASH
================================================

  1) PostgreSQL o'rnating va yangi database yarating:

     createdb aqua_nazorati

  2) Quyidagi jadvallarni yarating (psql orqali):

     psql -d aqua_nazorati -c "
       CREATE TYPE zone_status AS ENUM ('idle','irrigating','fertilizing','offline');
       CREATE TYPE schedule_type AS ENUM ('irrigate','fertilize');
       CREATE TYPE activity_action AS ENUM ('irrigate_start','irrigate_stop','fertilize_start','fertilize_stop','auto_irrigate','schedule_triggered','alert');

       CREATE TABLE zones (
         id SERIAL PRIMARY KEY,
         name TEXT NOT NULL,
         description TEXT,
         crop_type TEXT NOT NULL,
         area REAL NOT NULL,
         is_active BOOLEAN NOT NULL DEFAULT true,
         auto_irrigate BOOLEAN NOT NULL DEFAULT true,
         moisture_threshold REAL NOT NULL DEFAULT 30,
         current_moisture REAL NOT NULL DEFAULT 50,
         status zone_status NOT NULL DEFAULT 'idle',
         last_irrigated TIMESTAMP,
         created_at TIMESTAMP NOT NULL DEFAULT NOW()
       );

       CREATE TABLE sensor_readings (
         id SERIAL PRIMARY KEY,
         zone_id INTEGER NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
         moisture REAL NOT NULL,
         temperature REAL NOT NULL,
         humidity REAL NOT NULL,
         light_level REAL NOT NULL,
         recorded_at TIMESTAMP NOT NULL DEFAULT NOW()
       );

       CREATE TABLE schedules (
         id SERIAL PRIMARY KEY,
         zone_id INTEGER NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
         time TEXT NOT NULL,
         days_of_week TEXT[] NOT NULL,
         duration_minutes INTEGER NOT NULL,
         is_enabled BOOLEAN NOT NULL DEFAULT true,
         type schedule_type NOT NULL,
         fertilizer_type TEXT,
         created_at TIMESTAMP NOT NULL DEFAULT NOW()
       );

       CREATE TABLE activity_logs (
         id SERIAL PRIMARY KEY,
         zone_id INTEGER NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
         action activity_action NOT NULL,
         details TEXT NOT NULL,
         created_at TIMESTAMP NOT NULL DEFAULT NOW()
       );
     "

================================================
  2. BACKEND (API SERVER) NI ISHGA TUSHIRISH
================================================

  1) backend/ papkasiga o'ting:

     cd backend

  2) Environment o'zgaruvchilarini sozlang:

     export DATABASE_URL="postgresql://foydalanuvchi:parol@localhost:5432/aqua_nazorati"
     export PORT=8080
     export NODE_ENV=production

  3) Serverni ishga tushiring:

     node --enable-source-maps index.mjs

  Tekshirish:
     curl http://localhost:8080/api/healthz
     # {"status":"ok"} chiqishi kerak

  PM2 bilan doimiy ishlatish (tavsiya etiladi):
     npm install -g pm2
     pm2 start index.mjs --name aqua-api -- --enable-source-maps
     pm2 save
     pm2 startup

================================================
  3. FRONTEND NI NGINX BILAN SOZLASH
================================================

  1) Nginx o'rnating:

     sudo apt install nginx

  2) frontend/ papkasini server joyiga ko'chiring:

     sudo cp -r frontend/ /var/www/aqua-nazorati/

  3) Nginx konfiguratsiyasi (/etc/nginx/sites-available/aqua):

     server {
         listen 80;
         server_name sizning-domen.uz;  # domeningizni yozing

         root /var/www/aqua-nazorati;
         index index.html;

         # Frontend (React SPA)
         location / {
             try_files $uri $uri/ /index.html;
         }

         # Backend API proxy
         location /api/ {
             proxy_pass http://localhost:8080;
             proxy_http_version 1.1;
             proxy_set_header Upgrade $http_upgrade;
             proxy_set_header Connection 'upgrade';
             proxy_set_header Host $host;
             proxy_cache_bypass $http_upgrade;
         }
     }

  4) Konfiguratsiyani yoqing:

     sudo ln -s /etc/nginx/sites-available/aqua /etc/nginx/sites-enabled/
     sudo nginx -t
     sudo systemctl restart nginx

================================================
  4. SSL (HTTPS) SERTIFIKAT (ixtiyoriy)
================================================

     sudo apt install certbot python3-certbot-nginx
     sudo certbot --nginx -d sizning-domen.uz

================================================
  TAYYOR! Sayt ishlayapti.
================================================
